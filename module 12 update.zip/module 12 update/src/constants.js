const BASE_URL = "http://api.ratings.food.gov.uk/";
const API_VERSION = "2";

module.exports = {
    BASE_URL,
    API_VERSION
};


