async function id (parent, args, context) {
    return parent.BusinessTypeId;
}

module.exports = {
    id,
};
